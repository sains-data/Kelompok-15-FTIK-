-- INDEX berdasarkan waktu
CREATE NONCLUSTERED INDEX IX_FactKegiatan_Waktu
ON dbo.FACT_KEGIATAN (waktu_id)
INCLUDE (jumlah_peserta, prodi_id, layanan_id, kategori_id, organisasi_id);
GO

-- INDEX berdasarkan prodi
CREATE NONCLUSTERED INDEX IX_FactKegiatan_Prodi
ON dbo.FACT_KEGIATAN (prodi_id)
INCLUDE (waktu_id, jumlah_peserta, layanan_id, kategori_id, organisasi_id);
GO

-- INDEX berdasarkan layanan
CREATE NONCLUSTERED INDEX IX_FactKegiatan_Layanan
ON dbo.FACT_KEGIATAN (layanan_id)
INCLUDE (jumlah_peserta, waktu_id, prodi_id, kategori_id, organisasi_id);
GO

-- INDEX berdasarkan kategori
CREATE NONCLUSTERED INDEX IX_FactKegiatan_Kategori
ON dbo.FACT_KEGIATAN (kategori_id)
INCLUDE (jumlah_peserta, waktu_id, prodi_id, layanan_id, organisasi_id);
GO

-- INDEX berdasarkan organisasi
CREATE NONCLUSTERED INDEX IX_FactKegiatan_Organisasi
ON dbo.FACT_KEGIATAN (organisasi_id)
INCLUDE (jumlah_peserta, waktu_id, prodi_id, layanan_id, kategori_id);
GO

-- COVERING INDEX
CREATE NONCLUSTERED INDEX IX_FactKegiatan_Covering
ON dbo.FACT_KEGIATAN (waktu_id, prodi_id)
INCLUDE (jumlah_peserta, layanan_id, kategori_id, organisasi_id);
GO

-- COLUMNSTORE INDEX
CREATE NONCLUSTERED COLUMNSTORE INDEX NCCIX_Fact_Kegiatan
ON dbo.FACT_KEGIATAN
(
    waktu_id, prodi_id, layanan_id, kategori_id, organisasi_id,
    jumlah_peserta, durasi_menit
);
GO
