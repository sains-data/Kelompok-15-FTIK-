CREATE TABLE FACT_KEGIATAN (
    kegiatan_id INT IDENTITY(1,1) PRIMARY KEY,

    -- Foreign Keys
    waktu_id INT NOT NULL,
    prodi_id INT NULL,
    layanan_id INT NULL,
    kategori_id INT NULL,
    organisasi_id INT NULL,

    -- Measures 
    jumlah_peserta INT,
    durasi_menit INT,

    -- Relationships
    FOREIGN KEY (waktu_id) REFERENCES DIM_WAKTU(waktu_id),
    FOREIGN KEY (prodi_id) REFERENCES DIM_PRODI(prodi_id),
    FOREIGN KEY (layanan_id) REFERENCES DIM_LAYANAN(layanan_id),
    FOREIGN KEY (kategori_id) REFERENCES DIM_KATEGORI(kategori_id),
    FOREIGN KEY (organisasi_id) REFERENCES DIM_ORGANISASI(organisasi_id)
);
GO
