CREATE PROCEDURE usp_Load_Dim_Waktu
AS
BEGIN
    INSERT INTO DIM_WAKTU (tanggal, hari, bulan, tahun, minggu_ke)
    SELECT 
        s.tanggal,
        DATENAME(WEEKDAY, s.tanggal),
        MONTH(s.tanggal),
        YEAR(s.tanggal),
        DATEPART(WEEK, s.tanggal)
    FROM stg.Waktu s
    WHERE NOT EXISTS (SELECT 1 FROM DIM_WAKTU d WHERE d.tanggal = s.tanggal);

    PRINT 'DIM_WAKTU loaded.';
END;
GO

CREATE PROCEDURE usp_Load_Dim_Prodi
AS
BEGIN
    INSERT INTO DIM_PRODI (nama_prodi, jenjang, deskripsi)
    SELECT s.nama_prodi, s.jenjang, s.deskripsi
    FROM stg.Prodi s
    WHERE NOT EXISTS (SELECT 1 FROM DIM_PRODI d WHERE d.nama_prodi = s.nama_prodi);

    PRINT 'DIM_PRODI loaded.';
END;
GO

CREATE PROCEDURE usp_Load_Dim_Kategori
AS
BEGIN
    INSERT INTO DIM_KATEGORI (nama_kategori)
    SELECT nama_kategori
    FROM stg.Kategori s
    WHERE NOT EXISTS (
        SELECT 1 FROM DIM_KATEGORI d
        WHERE d.nama_kategori = s.nama_kategori
    );

    PRINT 'DIM_KATEGORI loaded.';
END;
GO

CREATE PROCEDURE usp_Load_Dim_Layanan
AS
BEGIN
    INSERT INTO DIM_LAYANAN (nama_layanan, kategori_layanan, deskripsi)
    SELECT nama_layanan, kategori_layanan, deskripsi
    FROM stg.Layanan s
    WHERE NOT EXISTS (SELECT 1 FROM DIM_LAYANAN d WHERE d.nama_layanan = s.nama_layanan);

    PRINT 'DIM_LAYANAN loaded.';
END;
GO

CREATE PROCEDURE usp_Load_Dim_Organisasi
AS
BEGIN
    INSERT INTO DIM_ORGANISASI (nama_unit, jenis_unit, pejabat)
    SELECT nama_unit, jenis_unit, pejabat
    FROM stg.Organisasi s
    WHERE NOT EXISTS (SELECT 1 FROM DIM_ORGANISASI d WHERE d.nama_unit = s.nama_unit);

    PRINT 'DIM_ORGANISASI loaded.';
END;
GO

CREATE PROCEDURE usp_Load_Fact_Kegiatan
AS
BEGIN
    INSERT INTO FACT_KEGIATAN
    (
        waktu_id, prodi_id, layanan_id, kategori_id, organisasi_id,
        jumlah_peserta, durasi_menit
    )
    SELECT
        w.waktu_id,
        p.prodi_id,
        l.layanan_id,
        k.kategori_id,
        o.organisasi_id,
        s.jumlah_peserta,
        s.durasi_menit
    FROM stg.Kegiatan s
    LEFT JOIN DIM_WAKTU w ON w.tanggal = s.tanggal
    LEFT JOIN DIM_PRODI p ON p.nama_prodi = s.nama_prodi
    LEFT JOIN DIM_LAYANAN l ON l.nama_layanan = s.nama_layanan
    LEFT JOIN DIM_KATEGORI k ON k.nama_kategori = s.nama_kategori
    LEFT JOIN DIM_ORGANISASI o ON o.nama_unit = s.nama_unit;

    PRINT 'FACT_KEGIATAN loaded.';
END;
GO

CREATE PROCEDURE usp_Load_Master_ETL
AS
BEGIN
    EXEC usp_Load_Dim_Waktu;
    EXEC usp_Load_Dim_Prodi;
    EXEC usp_Load_Dim_Layanan;
    EXEC usp_Load_Dim_Kategori;
    EXEC usp_Load_Dim_Organisasi;

    EXEC usp_Load_Fact_Kegiatan;

    PRINT 'MASTER ETL SUCCESS';
END;
GO
