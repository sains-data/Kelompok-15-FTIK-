USE DWMart_FTIK;
GO

CREATE SCHEMA stg;
GO

CREATE TABLE stg.Berita (
    judul NVARCHAR(300),
    tanggal_raw NVARCHAR(50),
    kategori_raw NVARCHAR(100),
    isi_berita NVARCHAR(MAX),
    url NVARCHAR(300),
    LoadDate DATETIME DEFAULT GETDATE()
);
GO

CREATE TABLE stg.Kegiatan (
    nama_kegiatan NVARCHAR(300),
    tanggal_raw NVARCHAR(50),
    waktu_raw NVARCHAR(50),
    lokasi NVARCHAR(200),
    penyelenggara NVARCHAR(200),
    kategori_raw NVARCHAR(100),
    jumlah_peserta_raw NVARCHAR(50),
    LoadDate DATETIME DEFAULT GETDATE()
);
GO

CREATE TABLE stg.Prodi (
    nama_prodi NVARCHAR(200),
    jenjang NVARCHAR(50),
    deskripsi NVARCHAR(MAX),
    kepala_prodi NVARCHAR(200),
    LoadDate DATETIME DEFAULT GETDATE()
);
GO

CREATE TABLE stg.Layanan (
    nama_layanan NVARCHAR(200),
    kategori_layanan_raw NVARCHAR(200),
    deskripsi NVARCHAR(MAX),
    LoadDate DATETIME DEFAULT GETDATE()
);
GO

CREATE TABLE stg.Organisasi (
    nama_unit NVARCHAR(200),
    jenis_unit_raw NVARCHAR(100),
    pejabat NVARCHAR(200),
    tahun_jabatan_raw NVARCHAR(50),
    LoadDate DATETIME DEFAULT GETDATE()
);
GO
