CREATE TABLE DIM_WAKTU (
    waktu_id INT IDENTITY(1,1) PRIMARY KEY,
    tanggal DATE NOT NULL,
    hari VARCHAR(15),
    bulan VARCHAR(15),
    tahun INT,
    minggu_ke INT
);
GO

CREATE TABLE DIM_PRODI (
    prodi_id INT IDENTITY(1,1) PRIMARY KEY,
    nama_prodi VARCHAR(200) NOT NULL,
    jenjang VARCHAR(50),
    deskripsi TEXT
);
GO

CREATE TABLE DIM_LAYANAN (
    layanan_id INT IDENTITY(1,1) PRIMARY KEY,
    nama_layanan VARCHAR(200) NOT NULL,
    kategori_layanan VARCHAR(100),
    deskripsi TEXT
);
GO

CREATE TABLE DIM_KATEGORI (
    kategori_id INT IDENTITY(1,1) PRIMARY KEY,
    nama_kategori VARCHAR(200) NOT NULL
);
GO

CREATE TABLE DIM_ORGANISASI (
    organisasi_id INT IDENTITY(1,1) PRIMARY KEY,
    nama_unit VARCHAR(200) NOT NULL,
    jenis_unit VARCHAR(100),
    pejabat VARCHAR(200)
);
GO

