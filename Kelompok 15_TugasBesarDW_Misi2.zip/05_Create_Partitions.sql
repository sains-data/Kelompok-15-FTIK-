USE DW_FTIK;
GO

ALTER TABLE FACT_KEGIATAN
ADD tahun INT;
GO

CREATE PARTITION FUNCTION PF_KegiatanTahun (INT)
AS RANGE RIGHT FOR VALUES
(
    2018,
    2019,
    2020,
    2021,
    2022,
    2023,
    2024,
    2025
);
GO


--------------------------------------------------------
-- 3. Create Partition Scheme
--------------------------------------------------------
CREATE PARTITION SCHEME PS_KegiatanTahun
AS PARTITION PF_KegiatanTahun
ALL TO ([PRIMARY]);
GO

CREATE TABLE dbo.FACT_KEGIATAN_PART
(
    kegiatan_id INT IDENTITY(1,1) NOT NULL,
    waktu_id INT NOT NULL,
    prodi_id INT NULL,
    layanan_id INT NULL,
    kategori_id INT NULL,
    organisasi_id INT NULL,
    jumlah_peserta INT,
    durasi_menit INT,
    tahun INT NOT NULL,

    PRIMARY KEY (tahun, kegiatan_id),

    FOREIGN KEY (waktu_id) REFERENCES DIM_WAKTU(waktu_id),
    FOREIGN KEY (prodi_id) REFERENCES DIM_PRODI(prodi_id),
    FOREIGN KEY (layanan_id) REFERENCES DIM_LAYANAN(layanan_id),
    FOREIGN KEY (kategori_id) REFERENCES DIM_KATEGORI(kategori_id),
    FOREIGN KEY (organisasi_id) REFERENCES DIM_ORGANISASI(organisasi_id)
)
ON PS_KegiatanTahun(tahun);
GO
