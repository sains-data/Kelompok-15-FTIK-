-- check null values
SELECT 
    'DIM_WAKTU' AS TableName,
    COUNT(*) AS TotalRows,
    SUM(CASE WHEN tanggal IS NULL THEN 1 ELSE 0 END) AS NullTanggal,
    SUM(CASE WHEN hari IS NULL THEN 1 ELSE 0 END) AS NullHari,
    SUM(CASE WHEN bulan IS NULL THEN 1 ELSE 0 END) AS NullBulan,
    SUM(CASE WHEN tahun IS NULL THEN 1 ELSE 0 END) AS NullTahun
FROM DIM_WAKTU;

SELECT 
    'DIM_PRODI' AS TableName,
    COUNT(*) AS TotalRows,
    SUM(CASE WHEN nama_prodi IS NULL THEN 1 ELSE 0 END) AS NullNamaProdi,
    SUM(CASE WHEN jenjang IS NULL THEN 1 ELSE 0 END) AS NullJenjang
FROM DIM_PRODI;

SELECT 
    'DIM_LAYANAN' AS TableName,
    COUNT(*) AS TotalRows,
    SUM(CASE WHEN nama_layanan IS NULL THEN 1 ELSE 0 END) AS NullNamaLayanan
FROM DIM_LAYANAN;

SELECT 
    'DIM_KATEGORI' AS TableName,
    COUNT(*) AS TotalRows,
    SUM(CASE WHEN nama_kategori IS NULL THEN 1 ELSE 0 END) AS NullNamaKategori
FROM DIM_KATEGORI;

SELECT 
    'DIM_ORGANISASI' AS TableName,
    COUNT(*) AS TotalRows,
    SUM(CASE WHEN nama_unit IS NULL THEN 1 ELSE 0 END) AS NullUnit
FROM DIM_ORGANISASI;

SELECT 
    'FACT_KEGIATAN' AS TableName,
    COUNT(*) AS TotalRows,
    SUM(CASE WHEN waktu_id IS NULL THEN 1 ELSE 0 END) AS NullWaktu,
    SUM(CASE WHEN kategori_id IS NULL THEN 1 ELSE 0 END) AS NullKategori
FROM FACT_KEGIATAN;

-- CEK ORPHAN RECORDS

-- Waktu orphan
SELECT COUNT(*) AS Orphan_Waktu
FROM FACT_KEGIATAN f
LEFT JOIN DIM_WAKTU d ON f.waktu_id = d.waktu_id
WHERE d.waktu_id IS NULL;

-- Prodi orphan
SELECT COUNT(*) AS Orphan_Prodi
FROM FACT_KEGIATAN f
LEFT JOIN DIM_PRODI d ON f.prodi_id = d.prodi_id
WHERE f.prodi_id IS NOT NULL AND d.prodi_id IS NULL;

-- Layanan orphan
SELECT COUNT(*) AS Orphan_Layanan
FROM FACT_KEGIATAN f
LEFT JOIN DIM_LAYANAN d ON f.layanan_id = d.layanan_id
WHERE f.layanan_id IS NOT NULL AND d.layanan_id IS NULL;

-- Kategori orphan
SELECT COUNT(*) AS Orphan_Kategori
FROM FACT_KEGIATAN f
LEFT JOIN DIM_KATEGORI d ON f.kategori_id = d.kategori_id
WHERE f.kategori_id IS NOT NULL AND d.kategori_id IS NULL;

-- Organisasi orphan
SELECT COUNT(*) AS Orphan_Organisasi
FROM FACT_KEGIATAN f
LEFT JOIN DIM_ORGANISASI d ON f.organisasi_id = d.organisasi_id
WHERE f.organisasi_id IS NOT NULL AND d.organisasi_id IS NULL;

-- VALID RANGE CHECK

SELECT 
    COUNT(*) AS Invalid_Peserta
FROM FACT_KEGIATAN
WHERE jumlah_peserta < 0 
   OR jumlah_peserta > 10000;   -- batas aman

SELECT 
    COUNT(*) AS Invalid_Durasi
FROM FACT_KEGIATAN
WHERE durasi_menit < 0 
   OR durasi_menit > 1440;  -- max 24 jam

CREATE TABLE dbo.FACT_KEGIATAN (
    kegiatan_id INT IDENTITY(1,1) PRIMARY KEY,
    waktu_id INT NULL,
    prodi_id INT NULL,
    layanan_id INT NULL,
    kategori_id INT NULL,
    organisasi_id INT NULL,
    jumlah_peserta INT,
    durasi_menit INT
);
GO

-- DUPLICATES

SELECT 
    waktu_id, prodi_id, layanan_id, kategori_id, organisasi_id,
    COUNT(*) AS DuplicateCount
FROM FACT_KEGIATAN
GROUP BY waktu_id, prodi_id, layanan_id, kategori_id, organisasi_id
HAVING COUNT(*) > 1;

-- RECORD COUNT RECONCILIATION

SELECT 'stg.Kegiatan' AS SourceName, COUNT(*) AS CountRows
FROM stg.Kegiatan
UNION ALL
SELECT 'Fact Kegiatan', COUNT(*)
FROM FACT_KEGIATAN;
