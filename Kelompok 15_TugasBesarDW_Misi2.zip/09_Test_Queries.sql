-- tes query
SET STATISTICS TIME ON;
SET STATISTICS IO ON;

SELECT 
    p.nama_prodi AS ProgramName,
    COUNT(f.kegiatan_id) AS TotalKegiatan,
    SUM(f.jumlah_peserta) AS TotalPeserta,
    AVG(f.durasi_menit) AS AvgDurasi
FROM FACT_KEGIATAN f
LEFT JOIN DIM_PRODI p ON f.prodi_id = p.prodi_id
GROUP BY p.nama_prodi
ORDER BY TotalKegiatan DESC;

SELECT
    w.tahun,
    w.bulan,
    COUNT(f.kegiatan_id) AS TotalKegiatan,
    SUM(f.jumlah_peserta) AS TotalPeserta
FROM FACT_KEGIATAN f
LEFT JOIN DIM_WAKTU w ON f.waktu_id = w.waktu_id
GROUP BY w.tahun, w.bulan
ORDER BY w.tahun, w.bulan;

SELECT
    l.nama_layanan,
    COUNT(f.kegiatan_id) AS JumlahKegiatan,
    SUM(f.jumlah_peserta) AS TotalPeserta,
    AVG(f.durasi_menit) AS RataRataDurasi
FROM FACT_KEGIATAN f
LEFT JOIN DIM_LAYANAN l ON f.layanan_id = l.layanan_id
GROUP BY l.nama_layanan
ORDER BY JumlahKegiatan DESC;

SELECT
    o.nama_unit,
    COUNT(f.kegiatan_id) AS TotalKegiatan,
    SUM(f.jumlah_peserta) AS TotalPeserta
FROM FACT_KEGIATAN f
LEFT JOIN DIM_ORGANISASI o ON f.organisasi_id = o.organisasi_id
GROUP BY o.nama_unit
ORDER BY TotalKegiatan DESC;

SELECT 
    f.kegiatan_id,
    p.nama_prodi,
    f.jumlah_peserta
FROM FACT_KEGIATAN f
LEFT JOIN DIM_PRODI p ON f.prodi_id = p.prodi_id
WHERE f.jumlah_peserta > (
    SELECT AVG(jumlah_peserta) + 2 * STDEV(jumlah_peserta) FROM FACT_KEGIATAN
)
ORDER BY f.jumlah_peserta DESC;

SELECT
    k.nama_kategori,
    COUNT(f.kegiatan_id) AS TotalKegiatan,
    SUM(f.durasi_menit) AS TotalDurasi
FROM FACT_KEGIATAN f
LEFT JOIN DIM_KATEGORI k ON f.kategori_id = k.kategori_id
GROUP BY k.nama_kategori
ORDER BY TotalKegiatan DESC;

CREATE INDEX IX_FACT_WAKTU ON FACT_KEGIATAN(waktu_id);
CREATE INDEX IX_FACT_PRODI ON FACT_KEGIATAN(prodi_id);
CREATE INDEX IX_FACT_LAYANAN ON FACT_KEGIATAN(layanan_id);
CREATE INDEX IX_FACT_KATEGORI ON FACT_KEGIATAN(kategori_id);
CREATE INDEX IX_FACT_ORG ON FACT_KEGIATAN(organisasi_id);
